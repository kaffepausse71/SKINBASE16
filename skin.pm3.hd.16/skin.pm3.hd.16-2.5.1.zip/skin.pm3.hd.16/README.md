The main goal of this fork is to add Helix support to this very fine skin made by JezzX.

What is done:

 - Created a new subtitles dialog to support new service based subtitles solution
 - Modified skin settings to reflect changes in subtitle handling
 - Fixed context menu
 - Fixed Settings window
 
A more up-to-date changelist with pictures is available here: http://forum.xbmc.org/showthread.php?tid=204055
Also you can leave comments on that thread if you have requests or bugs to reports.
