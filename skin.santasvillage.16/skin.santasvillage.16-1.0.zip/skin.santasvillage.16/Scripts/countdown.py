import xbmcplugin,xbmcgui,xbmcaddon,xbmc,os

import threading, time, traceback

from datetime import datetime, time
 
def dateDiffInSeconds(date1, date2):
  timedelta = date2 - date1
  return timedelta.days * 24 * 3600 + timedelta.seconds
 
def daysHoursMinutesSecondsFromSeconds(seconds):
    minutes, seconds = divmod(seconds, 60)
    hours, minutes = divmod(minutes, 60)
    days, hours = divmod(hours, 24)
    return (days, hours, minutes, seconds)


WINDOW_HOME = 10000

xbmcgui.Window(WINDOW_HOME).setProperty('Countdown.status', 'open')

while True:
    try: 
        christmas = datetime.strptime('2016-12-25 01:00:00', '%Y-%m-%d %H:%M:%S')
        diff = dateDiffInSeconds(datetime.now(), christmas)
        countdown = daysHoursMinutesSecondsFromSeconds(diff)
    except:
        diff = False
        break
        pass

    status = xbmcgui.Window(WINDOW_HOME).getProperty('Countdown.status')

    if (status == 'close'):
        break

    xbmc.sleep(500)
    xbmcgui.Window(WINDOW_HOME).setProperty('Countdown.days', str( countdown[0] ))
    xbmcgui.Window(WINDOW_HOME).setProperty('Countdown.hours', str( countdown[1] ))
    xbmcgui.Window(WINDOW_HOME).setProperty('Countdown.minutes', str( countdown[2] ))
    xbmcgui.Window(WINDOW_HOME).setProperty('Countdown.seconds', str( countdown[3] ))
