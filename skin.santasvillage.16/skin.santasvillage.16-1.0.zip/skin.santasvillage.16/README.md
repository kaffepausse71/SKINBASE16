## Chroma skin for Kodi 16 ISENGARD
Full-featured modern skin designed for Full HD TV screens.

![](http://i.imgur.com/8ifMwfF.jpg)

#### [Screenshots](https://github.com/Tgxcorporation/skin.chroma/wiki/Screenshots)

#### [Wiki](https://github.com/Tgxcorporation/skin.chroma/wiki)

#### [Changelog](https://github.com/Tgxcorporation/skin.chroma/blob/master/changelog.txt)

#### [Download from GitHub](https://github.com/Tgxcorporation/skin.chroma/wiki/Install-from-GitHub)

#### Thanks
All the Kodi/XBMC team and addon developers.

