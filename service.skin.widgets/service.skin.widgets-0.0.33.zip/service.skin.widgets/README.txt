INFORMATION FOR SKINNERS
------------------------

http://wiki.xbmc.org/index.php?title=Add-on:Skin_Widgets

